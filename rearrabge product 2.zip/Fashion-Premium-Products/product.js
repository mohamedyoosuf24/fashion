// product.js - Single product page, options change by category

const OPTIONS_BY_CATEGORY = {
  Dresses:  { label: "Size",     choices: ["XS", "S", "M", "L", "XL"] },
  Slippers: { label: "UK Size",  choices: ["6", "7", "8", "9", "10"] },
  Mobiles:  { label: "Storage",  choices: ["64 GB", "128 GB", "256 GB"] },
  Watches:  { label: "Strap",    choices: ["Leather", "Metal"] },
  Bags:     { label: "Colour",   choices: ["Black", "Tan", "Navy"] }
};

const DETAIL_ROWS = {
  Dresses:  ["Fit", "Free shipping above ₹999", "Easy 7-day returns"],
  Slippers: ["Fit", "Free shipping above ₹999", "Easy 7-day returns"],
  Mobiles:  ["Warranty", "Free shipping above ₹999", "7-day replacement"],
  Watches:  ["Warranty", "Free shipping above ₹999", "7-day returns"],
  Bags:     ["Material", "Free shipping above ₹999", "Easy 7-day returns"]
};

let currentProduct = null;
let selectedOption = null;

function getCart() { return JSON.parse(localStorage.getItem("cart")) || []; }
function saveCart(c) { localStorage.setItem("cart", JSON.stringify(c)); updateBadges(); }
function getWish() { return JSON.parse(localStorage.getItem("wishlist")) || []; }
function saveWish(w) { localStorage.setItem("wishlist", JSON.stringify(w)); updateBadges(); }

function updateBadges() {
  const cartEl = document.getElementById("cartCount");
  const wishEl = document.getElementById("wishCount");
  if (cartEl) cartEl.textContent = getCart().length;
  if (wishEl) wishEl.textContent = getWish().length;
}

function showStatus(message) {
  const el = document.getElementById("statusMsg");
  if (!el) return;
  el.textContent = message;
  el.classList.remove("hidden");
  clearTimeout(showStatus.timer);
  showStatus.timer = setTimeout(() => el.classList.add("hidden"), 2500);
}

function renderNotFound(box) {
  box.innerHTML = `
    <div class="col-span-full text-center py-10">
      <p class="text-lg font-semibold mb-3">Product not found</p>
      <a href="collection.html" class="inline-block bg-black text-white px-5 py-2.5 rounded-lg text-sm font-semibold">Back to Collections</a>
    </div>
  `;
}

function renderOptions(category) {
  const config = OPTIONS_BY_CATEGORY[category];
  if (!config) return "";
  const pills = config.choices.map((choice, i) => `
    <button type="button" data-option="${choice}"
      class="option-pill border px-3 py-1.5 rounded-lg text-xs font-semibold ${i === 0 ? "active" : ""}">
      ${choice}
    </button>
  `).join("");

  return `
    <div class="mt-6">
      <p class="text-xs font-bold uppercase text-gray-500 mb-2">Select ${config.label}</p>
      <div class="flex flex-wrap gap-2" id="optionGroup">${pills}</div>
    </div>
  `;
}

function renderDetails() {
  const box = document.getElementById("productDetailBox");
  if (!box || typeof allProducts === "undefined") return;

  const params = new URLSearchParams(window.location.search);
  const id = parseInt(params.get("id"), 10);
  const product = allProducts.find(p => p.id === id);

  if (!product) {
    document.title = "Product not found | Fabbro";
    renderNotFound(box);
    return;
  }

  currentProduct = product;
  const config = OPTIONS_BY_CATEGORY[product.category];
  selectedOption = config ? config.choices[0] : null;
  document.title = `${product.title} | Fabbro`;

  const discount = Math.round((1 - product.price / product.oldPrice) * 100);
  const rows = (DETAIL_ROWS[product.category] || []).map(r => `<li>${r}</li>`).join("");

  box.innerHTML = `
    <div>
      <img src="${product.image}" alt="${product.title}" class="w-full h-96 object-cover rounded-xl border">
    </div>

    <div class="flex flex-col justify-between">
      <div>
        <span class="text-xs uppercase font-bold text-gray-400">${product.category}</span>
        <h1 class="text-2xl md:text-3xl font-serif font-bold mt-1">${product.title}</h1>

        <div class="flex items-center gap-3 mt-3">
          <span class="text-2xl font-bold">₹${product.price}</span>
          <span class="text-sm line-through text-gray-400">₹${product.oldPrice}</span>
          <span class="text-xs font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded">${discount}% off</span>
        </div>

        <p class="text-sm text-gray-600 mt-4 leading-relaxed">${product.description}</p>

        ${renderOptions(product.category)}

        <ul class="mt-6 text-sm text-gray-600 space-y-1 list-disc list-inside">${rows}</ul>
      </div>

      <div>
        <div class="flex gap-3 mt-8">
          <button id="addCartBtn" class="flex-1 bg-black text-white py-3 rounded-xl text-sm font-bold hover:bg-gray-800">Add to Cart</button>
          <button id="addWishBtn" class="px-5 py-3 border border-black rounded-xl text-sm font-bold hover:bg-gray-100">♡ Wishlist</button>
        </div>
        <p id="statusMsg" class="hidden text-sm text-green-700 font-semibold mt-3"></p>
      </div>
    </div>
  `;

  bindDetailEvents();
}

function bindDetailEvents() {
  const group = document.getElementById("optionGroup");
  if (group) {
    group.addEventListener("click", e => {
      const btn = e.target.closest(".option-pill");
      if (!btn) return;
      selectedOption = btn.dataset.option;
      group.querySelectorAll(".option-pill").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  }

  document.getElementById("addCartBtn").addEventListener("click", addCurrentToCart);
  document.getElementById("addWishBtn").addEventListener("click", addCurrentToWishlist);
}

function addCurrentToCart() {
  const cart = getCart();
  const line = cart.find(c => c.id === currentProduct.id && c.variant === selectedOption);

  if (line) {
    line.qty = (line.qty || 1) + 1;
  } else {
    cart.push({
      id: currentProduct.id,
      title: currentProduct.title,
      category: currentProduct.category,
      price: currentProduct.price,
      oldPrice: currentProduct.oldPrice,
      image: currentProduct.image,
      description: currentProduct.description,
      variant: selectedOption,
      qty: 1
    });
  }

  saveCart(cart);
  const suffix = selectedOption ? ` (${selectedOption})` : "";
  showStatus(`${currentProduct.title}${suffix} added to cart`);
}

function addCurrentToWishlist() {
  const wish = getWish();
  if (wish.some(w => w.id === currentProduct.id)) {
    showStatus("Already in your wishlist");
    return;
  }
  wish.push(currentProduct);
  saveWish(wish);
  showStatus("Saved to wishlist");
}

document.addEventListener("DOMContentLoaded", () => {
  updateBadges();
  renderDetails();
});
