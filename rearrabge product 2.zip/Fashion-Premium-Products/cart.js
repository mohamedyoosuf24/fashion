// cart.js - Manages cart items and total
function getCart() { return JSON.parse(localStorage.getItem("cart")) || []; }
function saveCart(c) { localStorage.setItem("cart", JSON.stringify(c)); renderCart(); }
function getWish() { return JSON.parse(localStorage.getItem("wishlist")) || []; }

function updateBadges() {
  const cartEl = document.getElementById("cartCount");
  const wishEl = document.getElementById("wishCount");
  if (cartEl) cartEl.textContent = getCart().length;
  if (wishEl) wishEl.textContent = getWish().length;
}

function removeCartItem(index) {
  const cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
}

function checkoutOrder() {
  if (getCart().length === 0) return alert("Your cart is empty!");
  localStorage.removeItem("cart");
  renderCart();
  alert("Order placed successfully!");
}

function renderCart() {
  updateBadges();
  const box = document.getElementById("cartItems");
  const subEl = document.getElementById("subtotal");
  const totEl = document.getElementById("grandTotal");
  if (!box) return;

  const cart = getCart();
  if (cart.length === 0) {
    box.innerHTML = `<p class="text-sm text-gray-500">Your cart is empty. <a href="collections.html" class="underline font-semibold">Shop now</a></p>`;
    subEl.textContent = "₹0";
    totEl.textContent = "₹0";
    return;
  }

  let total = 0;
  box.innerHTML = cart.map((item, i) => {
    const qty = item.qty || 1;
    total += item.price * qty;
    return `
      <div class="flex items-center justify-between border-b pb-4 gap-3">
        <div class="flex items-center gap-3">
          <img src="${item.image}" alt="${item.title}" class="cart-row-img">
          <div>
            <h3 class="font-bold text-sm">${item.title}</h3>
            <p class="text-xs text-gray-500">${item.category} ${item.variant ? "• " + item.variant : ""}</p>
            <p class="font-bold text-sm mt-1">₹${item.price} × ${qty}</p>
          </div>
        </div>
        <button onclick="removeCartItem(${i})" class="text-xs text-red-600 font-semibold hover:underline">Remove</button>
      </div>
    `;
  }).join("");

  subEl.textContent = `₹${total}`;
  totEl.textContent = `₹${total}`;
}

document.addEventListener("DOMContentLoaded", renderCart);